
import React from 'react';
import { StyleSheet, TextInput } from 'react-native';
import { View, Text, Button } from 'react-native';

const Pass = ({ navigation }) => {

    
    
  return (
    <View style={styles.container}>
        <Text style={styles.title}>Forgot Password</Text>
        <Text style={styles.title}> Please enter your registered email or mobile to reset your Password.</Text>
        <Text>Email/Mobile number</Text>
        <TextInput></TextInput>
        
        <Button
            title="Recover Password"
            onPress={() => navigation.navigate('Check')}
            
          />
            
    </View>
  );
};
const styles = StyleSheet.create({
    container: {
      flex: 1,
  
    },
    title:{
        
    }
})
export default Pass;