
import React from 'react';
import { StyleSheet, TextInput } from 'react-native';
import { View, Text, Button } from 'react-native';

const Check = ({ navigation }) => {
    
  return (
    <View style={styles.container}>
            
        <Text style = {styles.Button}>  
            
            <Button 
            title=""
            
            onPress={() => navigation.navigate('Home')}
            
            
          /></Text> 
    </View>
  );

 
};
const styles = StyleSheet.create({
    container: {
      flex: 1,
      justifyContent: "center"
  
    },
    Button:{
        
        alignSelf : "center",

    },
})
export default Check;