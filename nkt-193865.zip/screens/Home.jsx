
import React from 'react';
import { StyleSheet, TextInput } from 'react-native';
import { View, Text, Button } from 'react-native';

const Home = ({ navigation }) => {
   
    
  return (
    <View style={styles.container}>
        <Text style = {styles.Text}> Email ID</Text>
        <TextInput > </TextInput>
        <Text style = {styles.Text}> PassWord</Text>
        <TextInput></TextInput>
            
        
        <Button
            title='forgot password?'
            onPress={() => navigation.navigate('Pass')}
            
          />
            <Button style={styles.regis}
            title="FOODS"
            onPress={() => navigation.navigate('Home')}
            color='#841584'
          />
    </View>
  );
};

const styles = StyleSheet.create({
    container: {
      flex: 1,
      alignSelf: "center",
      justifyContent: "center"
      
  
    },
    Text:{
        padding : 20,
        fontSize: 18,
        justifyContent : "center"
    },
   
})
export default Home;