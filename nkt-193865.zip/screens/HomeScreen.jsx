
import React from 'react';
import { StyleSheet, TextInput } from 'react-native';
import { View, Text, Button } from 'react-native';

const HomeScreen = ({ navigation }) => {
    
  return (
    <View style={styles.container}>
            
            <View style={styles.container}>
                <Image
                    style={styles.image}
                    source={require('C:\Users\buivi\Downloads\Vector.png')}
                />
            </View>
           <View style={styles.Button}>
            <Button 
            title="FOODU" 
            
            onPress={() => navigation.navigate('Home')}
            
            
          /></View> 
    </View>
  );

 
};
const styles = StyleSheet.create({
    container: {
      flex: 1,
      justifyContent: "center"
  
    },
    Button:{
        
        alignSelf : "center",
        

    },
})
export default HomeScreen;